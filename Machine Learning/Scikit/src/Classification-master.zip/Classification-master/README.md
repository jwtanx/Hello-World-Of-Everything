# Classification

**7 types of classification algorithms are discussed here:**
1. Logistic regression 
2. Naïve Bayes 
3. Stochastic Gradient Descent 
4. K Nearest Neighbours
5. Decision Tree 
6. Random Forest 
7. Support Vector Machine 
